package org.firstinspires.ftc.teamcode.auto;

public interface ICommand {
    public boolean runCommand();
    //This interface is the most garbage thing Dan has ever seen.
}