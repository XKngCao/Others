package org.firstinspires.ftc.teamcode.auto;

public enum CommandEnum {
    DRIVECOMMAND,
    TURNCOMMAND
}